#ifndef GENDER_H
#define GENDER_H

enum gender_t
{
    GENDER_MALE,
    GENDER_FEMALE
};


#endif
