// 12S21035 - Silviana Siagian
// 12S21042 - Samuel Siagian

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "libs/dorm.h"
#include "libs/student.h"



void getString(char *str) {
    fgets(str, 100, stdin);   // membaca string dari input keyboard
    int len = strlen(str);
    if (len > 0 && str[len-1] == '\n') {   // menghapus karakter newline jika ada
        str[len-1] = '\0';
    }
}



int main(int _argc, char **_argv)
{
    struct student_t *student = malloc(100 * sizeof(struct student_t));
    char input[100];
    char id[12];
    char name[50];
    char year[5];
    char *data;
    int i=0;
    int idsD=0;
    int x=1;
    
    struct dorm_t *dorms = malloc(100*sizeof(struct dorm_t));
    unsigned short kapasitas;
    
    while (x == 1)
    {

   fflush(stdin);
        input[0] = '\0';
        int c = 0;
        while (1)
        {
            char x = getchar();
            if (x == '\r')
            {
                continue;
            }
            if (x == '\n')
            {
                break;
            }
            input[c] = x;
            input[++c] = '\0';
        }



        if(strcmp(input, "---")==0){
            break;
        }
        else if (strstr(input, "student-print-all-detail") != NULL){

            print_detailstudent(student,i);

        }
        else if (strstr(input, "student-print-all")!=NULL)
        {
             print_student(student, i);
        } 
        else if (strstr(input, "student-add")!=NULL)
        {
            data = strtok(input, "#");
            data = strtok(NULL, "#");
            strcpy(id, data);
            data = strtok(NULL, "#");
            strcpy(name, data);
            data = strtok(NULL, "#");
            strcpy(year, data);
            data = strtok(NULL, "#");
            if (strcmp(data, "male")==0)
            {
                student[i] = create_student(id, name, year, GENDER_MALE);
            } 
            else if (strcmp(data, "female")==0)
            {
                student[i] = create_student(id, name, year, GENDER_FEMALE);
            }
            i++;
        }
        else if (strstr(input, "dorm-print-all-detail") != NULL)
        {
            print_detaildorm(dorms,idsD);
        }
        else if (strstr(input, "dorm-print-all") != NULL)
        {
            print_dorm(dorms,idsD);
        }
        else if (strstr(input, "dorm-add") != NULL)
        {
            data = strtok(input, "#");
            data = strtok(NULL, "#");
            strcpy(name, data);
            data = strtok(NULL, "#");
            kapasitas = atoi(data);
            data = strtok(NULL, "#");
            if (strcmp(data, "male")== 0)
            {
                dorms[idsD] = create_dorm(name, kapasitas, GENDER_MALE);
            }
            else if (strcmp(data, "female")== 0)
            {
                dorms[idsD] = create_dorm(name, kapasitas, GENDER_FEMALE);
            }
           idsD++;
        }
    }

        free(student);
        free(dorms);
        return 0;
    }